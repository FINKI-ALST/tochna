package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.exceptions.CourseNotFound;
import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import mk.ukim.finki.wp.lab.model.exceptions.UserNotFound;
import mk.ukim.finki.wp.lab.repository.CourseRepository;
import mk.ukim.finki.wp.lab.repository.StudentRepository;
import mk.ukim.finki.wp.lab.service.CourseService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;

    public CourseServiceImpl(CourseRepository courseRepository, StudentRepository studentRepository) {
        this.courseRepository = courseRepository;
        this.studentRepository = studentRepository;
    }

    @Override
    public List<Student> listStudentsByCourse(Long courseId) {
        return courseRepository.findAllStudentsByCourse(courseId);
    }

    @Override
    public Course addStudentInCourse(String username, Long courseId) {
        if(username.isEmpty())
        {
            throw new IllegalArgumentException();
        }
        Student student=studentRepository.findByUsername(username).orElseThrow(UserNotFound::new);
        Course course=courseRepository.findById(courseId).orElseThrow(CourseNotFound::new);
        return  courseRepository.addStudentToCourse(student,course);
    }
    public List<Course> listAll()
    {
        return courseRepository.findAllCourses();
    }
    public Optional<Course> findCourse(Long courseId)
    {
        return courseRepository.findById(courseId);
    }
}
