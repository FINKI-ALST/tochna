package mk.ukim.finki.wp.lab.bootstrap;

import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
public class DataHolder {
    public static List<Student> students=new ArrayList<Student>();
    public static List<Course> courses=new ArrayList<Course>();
    public static List<Student> studentsVP=new ArrayList<Student>();
    public static List<Student> studentsKE=new ArrayList<Student>();
    public static List<Student> studentsNICK=new ArrayList<Student>();
    public static List<Student> studentsMP=new ArrayList<Student>();
    public static List<Student> studentsV=new ArrayList<Student>();

    @PostConstruct
    public void init()
    {
        students.add(new Student("angelashumenkovska","ash","Angela","Shumenkovska"));
        students.add(new Student("simonabushevska","sb","Simona","Bushevska"));
        students.add(new Student("aleksandrastefanovska","as","Aleksandra","Stefanovska"));
        students.add(new Student("stefanstefanovski","ss","Stefan","Stefanovski"));
        students.add(new Student("marioshumenkovski","msh","Mario","Shumenkovski"));

        studentsVP.add(students.get(0));
        studentsVP.add(students.get(2));
        studentsVP.add(students.get(4));
        courses.add(new Course((long) 1,"Veb programiranje","Izucuvanje Spring Boot",studentsVP));

        studentsKE.add(students.get(1));
        studentsKE.add(students.get(2));
        studentsKE.add(students.get(3));
        courses.add(new Course((long) 2,"Kompjuterska Etika","Principi na eticko odnesuvanje pri koristenje na internetot",studentsKE));

        studentsNICK.add(students.get(3));
        studentsNICK.add(students.get(2));
        courses.add(new Course((long) 3,"Napredna interakcija covek kompjuter","Aplikacii za lugje so odreden hendikep",studentsNICK));

        studentsV.add(students.get(4));
        courses.add(new Course((long) 4,"Vizuelizacija","Vizueliziranje grafici",studentsV));

        studentsMP.add(students.get(0));
        studentsMP.add(students.get(2));
        courses.add(new Course((long) 5,"Mobilni platformi i programiranje","Izrabotka na Android aplikacija",studentsMP));
    }
}
