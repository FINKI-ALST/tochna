package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Course;
import mk.ukim.finki.wp.lab.model.Student;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CourseRepository {
    public List<Course> findAllCourses()
    {
        return DataHolder.courses;
    }
    public Optional<Course> findById(Long courseId)
    {
        return DataHolder.courses.stream().filter(r->r.getCourseId()==courseId).findFirst();
    }
    public  List<Student> findAllStudentsByCourse(Long courseId)
    {
        return DataHolder.courses.stream().filter(r->r.getCourseId()==courseId).findFirst().get().getStudents();
    }
    public Course addStudentToCourse(Student student, Course course)
    {
        course.getStudents().removeIf(r->r.getUsername().equals(student.getUsername()));
        course.getStudents().add(student);
        return course;
    }
}
